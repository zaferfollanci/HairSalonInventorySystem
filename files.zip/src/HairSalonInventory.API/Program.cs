using Microsoft.AspNetCore.Localization;
using System.Globalization;

// ...existing code...

// Add localization services
builder.Services.AddLocalization(options => options.ResourcesPath = "Resources");

// Supported cultures
var supportedCultures = new[] { new CultureInfo("en"), new CultureInfo("tr") };
builder.Services.Configure<RequestLocalizationOptions>(options =>
{
    options.DefaultRequestCulture = new RequestCulture("en");
    options.SupportedCultures = supportedCultures;
    options.SupportedUICultures = supportedCultures;
});

// ...existing code...

var app = builder.Build();

app.UseRequestLocalization(app.Services.GetRequiredService<IOptions<RequestLocalizationOptions>>().Value);

// ...existing code...