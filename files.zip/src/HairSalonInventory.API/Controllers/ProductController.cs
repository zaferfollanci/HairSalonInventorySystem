[HttpGet("barcode/{barcode}")]
public async Task<IActionResult> GetByBarcode(string barcode)
{
    var product = await _productService.GetByBarcodeAsync(barcode);
    if (product == null) return NotFound();
    return Ok(product);
}
[HttpGet("qr/{qrData}")]
public async Task<IActionResult> GetByQr(string qrData)
{
    var product = await _productService.GetByQrDataAsync(qrData);
    if (product == null) return NotFound();
    return Ok(product);
}