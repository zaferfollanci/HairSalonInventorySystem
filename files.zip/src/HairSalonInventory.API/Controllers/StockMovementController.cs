using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Threading.Tasks;
using HairSalonInventory.Application.Interfaces;
using HairSalonInventory.Application.DTOs;

namespace HairSalonInventory.API.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    [Authorize]
    public class StockMovementController : ControllerBase
    {
        private readonly IStockMovementService _service;

        public StockMovementController(IStockMovementService service)
        {
            _service = service;
        }

        [HttpGet]
        public async Task<IActionResult> GetAll([FromQuery] Guid? branchId = null, [FromQuery] Guid? productId = null)
        {
            var list = await _service.GetAllAsync(branchId, productId);
            return Ok(list);
        }

        [HttpGet("{id}")]
        public async Task<IActionResult> Get(Guid id)
        {
            var sm = await _service.GetByIdAsync(id);
            if (sm == null) return NotFound();
            return Ok(sm);
        }

        [HttpPost("entry")]
        [Authorize(Roles = "Admin,Staff,Cashier")]
        public async Task<IActionResult> AddEntry(CreateStockEntryDto dto)
        {
            var result = await _service.AddEntryAsync(dto);
            return Ok(result);
        }

        [HttpPost("exit")]
        [Authorize(Roles = "Admin,Staff,Cashier")]
        public async Task<IActionResult> AddExit(CreateStockExitDto dto)
        {
            var result = await _service.AddExitAsync(dto);
            return Ok(result);
        }

        [HttpDelete("{id}")]
        [Authorize(Roles = "Admin")]
        public async Task<IActionResult> Delete(Guid id)
        {
            await _service.DeleteAsync(id);
            return NoContent();
        }

        // Dynamic Exit Categories

        [HttpGet("exit-categories")]
        public async Task<IActionResult> GetExitCategories()
        {
            var cats = await _service.GetAllExitCategoriesAsync();
            return Ok(cats);
        }

        [HttpPost("exit-categories")]
        [Authorize(Roles = "Admin")]
        public async Task<IActionResult> AddExitCategory(CreateStockExitCategoryDto dto)
        {
            var cat = await _service.AddExitCategoryAsync(dto);
            return Ok(cat);
        }

        [HttpPut("exit-categories/{id}")]
        [Authorize(Roles = "Admin")]
        public async Task<IActionResult> UpdateExitCategory(Guid id, CreateStockExitCategoryDto dto)
        {
            var cat = await _service.UpdateExitCategoryAsync(id, dto);
            return Ok(cat);
        }

        [HttpDelete("exit-categories/{id}")]
        [Authorize(Roles = "Admin")]
        public async Task<IActionResult> DeleteExitCategory(Guid id)
        {
            await _service.DeleteExitCategoryAsync(id);
            return NoContent();
        }
    }
}