using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Threading.Tasks;
using HairSalonInventory.Application.Interfaces;

namespace HairSalonInventory.API.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    [Authorize]
    public class AnalyticsController : ControllerBase
    {
        private readonly IAnalyticsService _svc;
        public AnalyticsController(IAnalyticsService svc) => _svc = svc;

        [HttpGet("top-consumed")]
        public async Task<IActionResult> GetTopConsumed([FromQuery] DateTime from, [FromQuery] DateTime to, [FromQuery] Guid? branchId = null)
        {
            var result = await _svc.GetTopConsumedProductsAsync(from, to, branchId);
            return Ok(result);
        }

        [HttpGet("monthly")]
        public async Task<IActionResult> GetMonthly([FromQuery] DateTime from, [FromQuery] DateTime to, [FromQuery] Guid? branchId = null)
        {
            var result = await _svc.GetMonthlyStockMovementsAsync(from, to, branchId);
            return Ok(result);
        }

        [HttpGet("product-trend")]
        public async Task<IActionResult> GetProductTrend([FromQuery] Guid productId, [FromQuery] DateTime from, [FromQuery] DateTime to, [FromQuery] Guid? branchId = null)
        {
            var result = await _svc.GetProductTrendsAsync(productId, from, to, branchId);
            return Ok(result);
        }
    }
}