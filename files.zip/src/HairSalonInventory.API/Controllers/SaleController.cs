using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Threading.Tasks;
using HairSalonInventory.Application.Interfaces;
using HairSalonInventory.Application.DTOs;

namespace HairSalonInventory.API.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    [Authorize]
    public class SaleController : ControllerBase
    {
        private readonly ISaleService _service;
        public SaleController(ISaleService service) => _service = service;

        [HttpGet]
        public async Task<IActionResult> GetAll([FromQuery] Guid? branchId = null) => Ok(await _service.GetAllAsync(branchId));

        [HttpGet("{id}")]
        public async Task<IActionResult> Get(Guid id)
        {
            var s = await _service.GetByIdAsync(id);
            if (s == null) return NotFound();
            return Ok(s);
        }

        [HttpPost]
        [Authorize(Roles = "Admin,Staff,Cashier")]
        public async Task<IActionResult> Create(CreateSaleDto dto)
        {
            var s = await _service.CreateAsync(dto);
            return CreatedAtAction(nameof(Get), new { id = s.Id }, s);
        }

        [HttpDelete("{id}")]
        [Authorize(Roles = "Admin")]
        public async Task<IActionResult> Delete(Guid id)
        {
            await _service.DeleteAsync(id);
            return NoContent();
        }
    }
}