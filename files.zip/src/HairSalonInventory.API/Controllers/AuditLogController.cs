using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Threading.Tasks;
using HairSalonInventory.Application.Interfaces;

namespace HairSalonInventory.API.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    [Authorize(Roles = "Admin")] // Only Admins view logs
    public class AuditLogController : ControllerBase
    {
        private readonly IAuditLogService _service;
        public AuditLogController(IAuditLogService service) => _service = service;

        [HttpGet]
        public async Task<IActionResult> Query(
            [FromQuery] DateTime? from,
            [FromQuery] DateTime? to,
            [FromQuery] string userName,
            [FromQuery] string actionType,
            [FromQuery] string entityName,
            [FromQuery] int page = 1,
            [FromQuery] int pageSize = 50)
        {
            var logs = await _service.QueryAsync(from, to, userName, actionType, entityName, page, pageSize);
            return Ok(logs);
        }
    }
}