using Microsoft.AspNetCore.SignalR;

namespace HairSalonInventory.Application.SignalR
{
    public class NotificationHub : Hub
    {
    }
}