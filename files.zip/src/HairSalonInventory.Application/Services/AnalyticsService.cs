using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using HairSalonInventory.Application.DTOs;
using HairSalonInventory.Application.Interfaces;
using HairSalonInventory.Infrastructure.Repositories;
using HairSalonInventory.Domain.Entities;

namespace HairSalonInventory.Application.Services
{
    public class AnalyticsService : IAnalyticsService
    {
        private readonly IStockMovementRepository _smRepo;
        private readonly IProductRepository _productRepo;

        public AnalyticsService(IStockMovementRepository smRepo, IProductRepository productRepo)
        {
            _smRepo = smRepo;
            _productRepo = productRepo;
        }

        public async Task<List<ProductConsumptionDto>> GetTopConsumedProductsAsync(DateTime from, DateTime to, Guid? branchId = null)
        {
            var movements = await _smRepo.GetAllAsync(branchId);
            var products = await _productRepo.GetAllAsync(branchId);

            // Only Exits within date range
            var exits = movements
                .Where(m => m.Type == StockMovementType.Exit && m.Date >= from && m.Date <= to);

            var result = exits
                .GroupBy(m => m.ProductId)
                .Select(g =>
                {
                    var prod = products.FirstOrDefault(p => p.Id == g.Key);
                    return new ProductConsumptionDto
                    {
                        ProductId = g.Key,
                        ProductName = prod?.Name ?? "Unknown",
                        Unit = prod?.Unit ?? "",
                        TotalConsumed = g.Sum(m => m.Amount)
                    };
                })
                .OrderByDescending(p => p.TotalConsumed)
                .Take(10)
                .ToList();
            return result;
        }

        public async Task<List<MonthlyStockMovementDto>> GetMonthlyStockMovementsAsync(DateTime from, DateTime to, Guid? branchId = null)
        {
            var movements = await _smRepo.GetAllAsync(branchId);

            var monthly = movements
                .Where(m => m.Date >= from && m.Date <= to)
                .GroupBy(m => new { m.Date.Year, m.Date.Month })
                .Select(g => new MonthlyStockMovementDto
                {
                    Year = g.Key.Year,
                    Month = g.Key.Month,
                    TotalEntries = g.Where(m => m.Type == StockMovementType.Entry).Sum(m => m.Amount),
                    TotalExits = g.Where(m => m.Type == StockMovementType.Exit).Sum(m => m.Amount)
                })
                .OrderBy(g => g.Year).ThenBy(g => g.Month)
                .ToList();
            return monthly;
        }

        public async Task<List<StockTrendDto>> GetProductTrendsAsync(Guid productId, DateTime from, DateTime to, Guid? branchId = null)
        {
            var movements = await _smRepo.GetAllAsync(branchId, productId);
            var prod = (await _productRepo.GetAllAsync(branchId)).FirstOrDefault(p => p.Id == productId);

            var monthly = movements
                .Where(m => m.Date >= from && m.Date <= to)
                .GroupBy(m => new { m.Date.Year, m.Date.Month })
                .Select(g => new MonthlyStockMovementDto
                {
                    Year = g.Key.Year,
                    Month = g.Key.Month,
                    TotalEntries = g.Where(m => m.Type == StockMovementType.Entry).Sum(m => m.Amount),
                    TotalExits = g.Where(m => m.Type == StockMovementType.Exit).Sum(m => m.Amount)
                })
                .OrderBy(g => g.Year).ThenBy(g => g.Month)
                .ToList();

            return new List<StockTrendDto>
            {
                new StockTrendDto
                {
                    ProductId = productId,
                    ProductName = prod?.Name ?? "Unknown",
                    MonthlyMovements = monthly
                }
            };
        }
    }
}