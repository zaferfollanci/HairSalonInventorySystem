// ... within AddExitAsync or AddEntryAsync, after movement is saved:

// Check low stock
var allMovements = await _stockRepo.GetAllAsync(null, dto.ProductId);
var stock = allMovements.Where(x => x.Type == StockMovementType.Entry).Sum(x => x.Amount)
    - allMovements.Where(x => x.Type == StockMovementType.Exit).Sum(x => x.Amount);

if (stock <= product.MinimumStockLevel)
{
    // Fetch admin emails from UserRepository or config
    var adminEmails = await _userRepo.GetAdminEmailsAsync(product.BranchId); // implement this
    await _notificationService.NotifyLowStockAsync(product.Id, product.Name, stock, product.MinimumStockLevel, adminEmails);
}