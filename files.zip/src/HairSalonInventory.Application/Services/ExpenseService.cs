using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using HairSalonInventory.Application.DTOs;
using HairSalonInventory.Application.Interfaces;
using HairSalonInventory.Domain.Entities;
using HairSalonInventory.Infrastructure.Repositories;

namespace HairSalonInventory.Application.Services
{
    public class ExpenseService : IExpenseService
    {
        private readonly IExpenseRepository _repo;
        private readonly IBranchRepository _branchRepo;

        public ExpenseService(IExpenseRepository repo, IBranchRepository branchRepo)
        {
            _repo = repo;
            _branchRepo = branchRepo;
        }

        public async Task<IEnumerable<ExpenseDto>> GetAllAsync(Guid? branchId = null)
        {
            var expenses = await _repo.GetAllAsync(branchId);
            return expenses.Select(e => new ExpenseDto
            {
                Id = e.Id,
                Description = e.Description,
                Amount = e.Amount,
                Date = e.Date,
                BranchName = e.Branch?.Name,
                Category = e.Category
            });
        }

        public async Task<ExpenseDto> GetByIdAsync(Guid id)
        {
            var e = await _repo.GetByIdAsync(id);
            return new ExpenseDto
            {
                Id = e.Id,
                Description = e.Description,
                Amount = e.Amount,
                Date = e.Date,
                BranchName = e.Branch?.Name,
                Category = e.Category
            };
        }

        public async Task<ExpenseDto> CreateAsync(CreateExpenseDto dto)
        {
            var expense = new Expense
            {
                Id = Guid.NewGuid(),
                Description = dto.Description,
                Amount = dto.Amount,
                Date = DateTime.UtcNow,
                BranchId = dto.BranchId,
                Category = dto.Category
            };
            await _repo.AddAsync(expense);
            return await GetByIdAsync(expense.Id);
        }

        public async Task DeleteAsync(Guid id)
        {
            await _repo.DeleteAsync(id);
        }
    }
}