using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using HairSalonInventory.Application.DTOs;
using HairSalonInventory.Application.Interfaces;
using HairSalonInventory.Domain.Entities;
using HairSalonInventory.Infrastructure.Repositories;
using Microsoft.Extensions.Configuration;
using System.Net.Mail;
using System.Net;
using Microsoft.AspNetCore.SignalR;
using HairSalonInventory.Application.SignalR;

namespace HairSalonInventory.Application.Services
{
    public class NotificationService : INotificationService
    {
        private readonly INotificationRepository _repo;
        private readonly IConfiguration _config;
        private readonly IHubContext<NotificationHub> _hub;

        public NotificationService(INotificationRepository repo, IConfiguration config, IHubContext<NotificationHub> hub)
        {
            _repo = repo;
            _config = config;
            _hub = hub;
        }

        public async Task<List<NotificationDto>> GetUnreadAsync(Guid? userId = null, int limit = 10)
        {
            var list = await _repo.GetUnreadAsync(userId, limit);
            return list.Select(ToDto).ToList();
        }

        public async Task<List<NotificationDto>> GetAllAsync(Guid? userId = null, int limit = 50)
        {
            var list = await _repo.GetAllAsync(userId, limit);
            return list.Select(ToDto).ToList();
        }

        public async Task MarkAsReadAsync(Guid notificationId)
        {
            await _repo.MarkAsReadAsync(notificationId);
        }

        public async Task MarkAllAsReadAsync(Guid? userId = null)
        {
            await _repo.MarkAllAsReadAsync(userId);
        }

        public async Task NotifyLowStockAsync(Guid productId, string productName, decimal currentStock, decimal minStock, IEnumerable<string> adminEmails)
        {
            var message = $"Low stock alert: <b>{productName}</b> ({currentStock}) below minimum ({minStock}).";
            var notif = new Notification
            {
                Id = Guid.NewGuid(),
                Type = NotificationType.LowStock,
                Message = message,
                CreatedAt = DateTime.UtcNow,
                ProductId = productId,
                ProductName = productName
            };
            await _repo.AddAsync(notif);
            await BroadcastAsync(notif);

            // Send email
            await SendEmailAsync(adminEmails, "Low Stock Alert", message);
        }

        public async Task NotifyCriticalAsync(string message, IEnumerable<string> adminEmails)
        {
            var notif = new Notification
            {
                Id = Guid.NewGuid(),
                Type = NotificationType.Critical,
                Message = message,
                CreatedAt = DateTime.UtcNow
            };
            await _repo.AddAsync(notif);
            await BroadcastAsync(notif);
            await SendEmailAsync(adminEmails, "Critical Inventory Alert", message);
        }

        public async Task BroadcastAsync(Notification notification)
        {
            // Uses SignalR to update all connected clients
            await _hub.Clients.All.SendAsync("ReceiveNotification", ToDto(notification));
        }

        private NotificationDto ToDto(Notification n) => new()
        {
            Id = n.Id,
            Type = n.Type.ToString(),
            Message = n.Message,
            IsRead = n.IsRead,
            CreatedAt = n.CreatedAt,
            ProductId = n.ProductId,
            ProductName = n.ProductName
        };

        private async Task SendEmailAsync(IEnumerable<string> to, string subject, string body)
        {
            var smtpHost = _config["Smtp:Host"];
            var smtpPort = int.Parse(_config["Smtp:Port"] ?? "25");
            var smtpUser = _config["Smtp:User"];
            var smtpPass = _config["Smtp:Pass"];
            var from = _config["Smtp:From"];

            using var client = new SmtpClient(smtpHost, smtpPort)
            {
                Credentials = new NetworkCredential(smtpUser, smtpPass),
                EnableSsl = true
            };
            var mail = new MailMessage()
            {
                From = new MailAddress(from),
                Subject = subject,
                Body = body,
                IsBodyHtml = true
            };
            foreach (var addr in to) mail.To.Add(addr);
            await client.SendMailAsync(mail);
        }
    }
}