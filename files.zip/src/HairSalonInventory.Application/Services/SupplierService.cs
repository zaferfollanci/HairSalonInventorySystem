using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using HairSalonInventory.Application.DTOs;
using HairSalonInventory.Application.Interfaces;
using HairSalonInventory.Domain.Entities;
using HairSalonInventory.Infrastructure.Repositories;

namespace HairSalonInventory.Application.Services
{
    public class SupplierService : ISupplierService
    {
        private readonly ISupplierRepository _repo;
        public SupplierService(ISupplierRepository repo) => _repo = repo;

        public async Task<IEnumerable<SupplierDto>> GetAllAsync()
        {
            var list = await _repo.GetAllAsync();
            return list.Select(s => new SupplierDto
            {
                Id = s.Id,
                Name = s.Name,
                ContactInfo = s.ContactInfo
            });
        }

        public async Task<SupplierDto> GetByIdAsync(Guid id)
        {
            var s = await _repo.GetByIdAsync(id);
            if (s == null) return null;
            return new SupplierDto
            {
                Id = s.Id,
                Name = s.Name,
                ContactInfo = s.ContactInfo
            };
        }

        public async Task<SupplierDto> CreateAsync(CreateSupplierDto dto)
        {
            var s = new Supplier
            {
                Id = Guid.NewGuid(),
                Name = dto.Name,
                ContactInfo = dto.ContactInfo
            };
            await _repo.AddAsync(s);
            return await GetByIdAsync(s.Id);
        }

        public async Task<SupplierDto> UpdateAsync(Guid id, CreateSupplierDto dto)
        {
            var s = await _repo.GetByIdAsync(id);
            if (s == null) throw new Exception("Supplier not found");
            s.Name = dto.Name;
            s.ContactInfo = dto.ContactInfo;
            await _repo.UpdateAsync(s);
            return await GetByIdAsync(s.Id);
        }

        public async Task DeleteAsync(Guid id)
        {
            await _repo.DeleteAsync(id);
        }
    }
}