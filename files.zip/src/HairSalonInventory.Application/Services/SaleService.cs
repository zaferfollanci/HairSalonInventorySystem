using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using HairSalonInventory.Application.DTOs;
using HairSalonInventory.Application.Interfaces;
using HairSalonInventory.Domain.Entities;
using HairSalonInventory.Infrastructure.Repositories;

namespace HairSalonInventory.Application.Services
{
    public class SaleService : ISaleService
    {
        private readonly ISaleRepository _repo;
        private readonly IProductRepository _productRepo;
        private readonly IBranchRepository _branchRepo;

        public SaleService(ISaleRepository repo, IProductRepository productRepo, IBranchRepository branchRepo)
        {
            _repo = repo;
            _productRepo = productRepo;
            _branchRepo = branchRepo;
        }

        public async Task<IEnumerable<SaleDto>> GetAllAsync(Guid? branchId = null)
        {
            var sales = await _repo.GetAllAsync(branchId);
            return sales.Select(s => new SaleDto
            {
                Id = s.Id,
                ProductName = s.Product?.Name,
                Quantity = s.Quantity,
                UnitPrice = s.UnitPrice,
                Total = s.Total,
                Date = s.Date,
                CustomerName = s.CustomerName,
                BranchName = s.Branch?.Name
            });
        }

        public async Task<SaleDto> GetByIdAsync(Guid id)
        {
            var s = await _repo.GetByIdAsync(id);
            return new SaleDto
            {
                Id = s.Id,
                ProductName = s.Product?.Name,
                Quantity = s.Quantity,
                UnitPrice = s.UnitPrice,
                Total = s.Total,
                Date = s.Date,
                CustomerName = s.CustomerName,
                BranchName = s.Branch?.Name
            };
        }

        public async Task<SaleDto> CreateAsync(CreateSaleDto dto)
        {
            var sale = new Sale
            {
                Id = Guid.NewGuid(),
                ProductId = dto.ProductId,
                Quantity = dto.Quantity,
                UnitPrice = dto.UnitPrice,
                CustomerName = dto.CustomerName,
                Date = DateTime.UtcNow,
                BranchId = dto.BranchId
            };
            await _repo.AddAsync(sale);
            return await GetByIdAsync(sale.Id);
        }

        public async Task DeleteAsync(Guid id)
        {
            await _repo.DeleteAsync(id);
        }
    }
}