public async Task<ProductDto> GetByBarcodeAsync(string barcode)
{
    var p = await _productRepo.GetByBarcodeAsync(barcode);
    return p == null ? null : MapToDto(p);
}
public async Task<ProductDto> GetByQrDataAsync(string qrData)
{
    var p = await _productRepo.GetByQrDataAsync(qrData);
    return p == null ? null : MapToDto(p);
}