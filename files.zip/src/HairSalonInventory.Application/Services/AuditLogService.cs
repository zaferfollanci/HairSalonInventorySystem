using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using HairSalonInventory.Application.DTOs;
using HairSalonInventory.Application.Interfaces;
using HairSalonInventory.Domain.Entities;
using HairSalonInventory.Infrastructure.Repositories;

namespace HairSalonInventory.Application.Services
{
    public class AuditLogService : IAuditLogService
    {
        private readonly IAuditLogRepository _repo;

        public AuditLogService(IAuditLogRepository repo)
        {
            _repo = repo;
        }

        public async Task LogAsync(string actionType, string entityName, string entityId, string details, Guid? userId, string userName, string ipAddress)
        {
            var log = new AuditLog
            {
                Id = Guid.NewGuid(),
                Timestamp = DateTime.UtcNow,
                ActionType = actionType,
                EntityName = entityName,
                EntityId = entityId,
                Details = details,
                UserId = userId,
                UserName = userName,
                IpAddress = ipAddress
            };
            await _repo.AddAsync(log);
        }

        public async Task<IEnumerable<AuditLogDto>> QueryAsync(DateTime? from, DateTime? to, string userName, string actionType, string entityName, int page = 1, int pageSize = 50)
        {
            var logs = await _repo.QueryAsync(from, to, userName, actionType, entityName, page, pageSize);
            return logs.Select(x => new AuditLogDto
            {
                Id = x.Id,
                Timestamp = x.Timestamp,
                UserName = x.UserName,
                ActionType = x.ActionType,
                EntityName = x.EntityName,
                EntityId = x.EntityId,
                Details = x.Details,
                IpAddress = x.IpAddress
            });
        }
    }
}