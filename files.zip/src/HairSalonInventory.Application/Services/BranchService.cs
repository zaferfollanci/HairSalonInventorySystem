using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using HairSalonInventory.Application.DTOs;
using HairSalonInventory.Application.Interfaces;
using HairSalonInventory.Domain.Entities;
using HairSalonInventory.Infrastructure.Repositories;

namespace HairSalonInventory.Application.Services
{
    public class BranchService : IBranchService
    {
        private readonly IBranchRepository _repo;
        public BranchService(IBranchRepository repo) => _repo = repo;

        public async Task<IEnumerable<BranchDto>> GetAllAsync()
        {
            var list = await _repo.GetAllAsync();
            return list.Select(b => new BranchDto
            {
                Id = b.Id,
                Name = b.Name,
                Address = b.Address
            });
        }

        public async Task<BranchDto> GetByIdAsync(Guid id)
        {
            var b = await _repo.GetByIdAsync(id);
            if (b == null) return null;
            return new BranchDto
            {
                Id = b.Id,
                Name = b.Name,
                Address = b.Address
            };
        }

        public async Task<BranchDto> CreateAsync(CreateBranchDto dto)
        {
            var b = new Branch
            {
                Id = Guid.NewGuid(),
                Name = dto.Name,
                Address = dto.Address
            };
            await _repo.AddAsync(b);
            return await GetByIdAsync(b.Id);
        }

        public async Task<BranchDto> UpdateAsync(Guid id, CreateBranchDto dto)
        {
            var b = await _repo.GetByIdAsync(id);
            if (b == null) throw new Exception("Branch not found");
            b.Name = dto.Name;
            b.Address = dto.Address;
            await _repo.UpdateAsync(b);
            return await GetByIdAsync(b.Id);
        }

        public async Task DeleteAsync(Guid id)
        {
            await _repo.DeleteAsync(id);
        }
    }
}