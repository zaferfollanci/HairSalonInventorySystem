using System;

namespace HairSalonInventory.Application.DTOs
{
    public class NotificationDto
    {
        public Guid Id { get; set; }
        public string Type { get; set; }
        public string Message { get; set; }
        public bool IsRead { get; set; }
        public DateTime CreatedAt { get; set; }
        public Guid? ProductId { get; set; }
        public string ProductName { get; set; }
    }
}