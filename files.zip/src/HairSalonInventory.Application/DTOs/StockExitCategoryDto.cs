using System;

namespace HairSalonInventory.Application.DTOs
{
    public class StockExitCategoryDto
    {
        public Guid Id { get; set; }
        public string Name { get; set; }
    }

    public class CreateStockExitCategoryDto
    {
        public string Name { get; set; }
    }
}