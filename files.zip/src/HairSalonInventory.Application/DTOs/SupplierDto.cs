using System;

namespace HairSalonInventory.Application.DTOs
{
    public class SupplierDto
    {
        public Guid Id { get; set; }
        public string Name { get; set; }
        public string ContactInfo { get; set; }
    }

    public class CreateSupplierDto
    {
        public string Name { get; set; }
        public string ContactInfo { get; set; }
    }
}