using System;
using System.ComponentModel.DataAnnotations;

namespace HairSalonInventory.Application.DTOs
{
    public class RegisterDto
    {
        [Required] public string Username { get; set; }
        [Required][EmailAddress] public string Email { get; set; }
        [Required][MinLength(6)] public string Password { get; set; }
        [Required] public string Role { get; set; } // Admin, Staff, Cashier
        [Required] public Guid BranchId { get; set; }
    }

    public class LoginDto
    {
        [Required] public string Username { get; set; }
        [Required] public string Password { get; set; }
    }

    public class AuthResultDto
    {
        public string Token { get; set; }
        public string Username { get; set; }
        public string Role { get; set; }
        public Guid UserId { get; set; }
        public Guid BranchId { get; set; }
    }
}