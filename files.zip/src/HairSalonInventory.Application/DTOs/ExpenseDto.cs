using System;

namespace HairSalonInventory.Application.DTOs
{
    public class ExpenseDto
    {
        public Guid Id { get; set; }
        public string Description { get; set; }
        public decimal Amount { get; set; }
        public DateTime Date { get; set; }
        public string BranchName { get; set; }
        public string Category { get; set; }
    }

    public class CreateExpenseDto
    {
        public string Description { get; set; }
        public decimal Amount { get; set; }
        public Guid BranchId { get; set; }
        public string Category { get; set; }
    }
}