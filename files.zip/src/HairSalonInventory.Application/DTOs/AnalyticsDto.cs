using System;
using System.Collections.Generic;

namespace HairSalonInventory.Application.DTOs
{
    public class ProductConsumptionDto
    {
        public Guid ProductId { get; set; }
        public string ProductName { get; set; }
        public decimal TotalConsumed { get; set; }
        public string Unit { get; set; }
    }

    public class MonthlyStockMovementDto
    {
        public int Year { get; set; }
        public int Month { get; set; }
        public decimal TotalEntries { get; set; }
        public decimal TotalExits { get; set; }
    }

    public class StockTrendDto
    {
        public Guid ProductId { get; set; }
        public string ProductName { get; set; }
        public List<MonthlyStockMovementDto> MonthlyMovements { get; set; }
    }
}