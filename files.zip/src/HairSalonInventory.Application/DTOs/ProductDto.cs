using System;

namespace HairSalonInventory.Application.DTOs
{
    public class ProductDto
    {
        public Guid Id { get; set; }
        public string Name { get; set; }
        public string Unit { get; set; }
        public int MinimumStockLevel { get; set; }
        public DateTime? ExpirationDate { get; set; }
        public string SupplierName { get; set; }
        public Guid SupplierId { get; set; }
        public string BranchName { get; set; }
        public Guid BranchId { get; set; }
        public bool IsActive { get; set; }
    }

    public class CreateProductDto
    {
        public string Name { get; set; }
        public string Unit { get; set; }
        public int MinimumStockLevel { get; set; }
        public DateTime? ExpirationDate { get; set; }
        public Guid? SupplierId { get; set; }
        public Guid BranchId { get; set; }
    }

    public class UpdateProductDto : CreateProductDto
    {
        public Guid Id { get; set; }
    }
}