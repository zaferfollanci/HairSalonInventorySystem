using System;

namespace HairSalonInventory.Application.DTOs
{
    public class StockMovementDto
    {
        public Guid Id { get; set; }
        public string Type { get; set; }
        public Guid ProductId { get; set; }
        public string ProductName { get; set; }
        public decimal Amount { get; set; }
        public DateTime Date { get; set; }
        public string Notes { get; set; }
        public Guid? ExitCategoryId { get; set; }
        public string ExitCategoryName { get; set; }
        public Guid? UserId { get; set; }
        public string UserName { get; set; }
        public Guid BranchId { get; set; }
        public string BranchName { get; set; }
    }

    public class CreateStockEntryDto
    {
        public Guid ProductId { get; set; }
        public decimal Amount { get; set; }
        public string Notes { get; set; }
        public Guid BranchId { get; set; }
        public Guid? UserId { get; set; }
    }

    public class CreateStockExitDto
    {
        public Guid ProductId { get; set; }
        public decimal Amount { get; set; }
        public string Notes { get; set; }
        public Guid ExitCategoryId { get; set; }
        public Guid BranchId { get; set; }
        public Guid? UserId { get; set; }
    }
}