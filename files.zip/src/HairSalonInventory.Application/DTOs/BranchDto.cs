using System;

namespace HairSalonInventory.Application.DTOs
{
    public class BranchDto
    {
        public Guid Id { get; set; }
        public string Name { get; set; }
        public string Address { get; set; }
    }

    public class CreateBranchDto
    {
        public string Name { get; set; }
        public string Address { get; set; }
    }
}