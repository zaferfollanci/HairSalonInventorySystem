using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using HairSalonInventory.Application.DTOs;

namespace HairSalonInventory.Application.Interfaces
{
    public interface IAuditLogService
    {
        Task LogAsync(string actionType, string entityName, string entityId, string details, Guid? userId, string userName, string ipAddress);
        Task<IEnumerable<AuditLogDto>> QueryAsync(DateTime? from, DateTime? to, string userName, string actionType, string entityName, int page = 1, int pageSize = 50);
    }
}