using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using HairSalonInventory.Application.DTOs;

namespace HairSalonInventory.Application.Interfaces
{
    public interface IStockMovementService
    {
        Task<IEnumerable<StockMovementDto>> GetAllAsync(Guid? branchId = null, Guid? productId = null);
        Task<StockMovementDto> GetByIdAsync(Guid id);
        Task<StockMovementDto> AddEntryAsync(CreateStockEntryDto dto);
        Task<StockMovementDto> AddExitAsync(CreateStockExitDto dto);
        Task DeleteAsync(Guid id);

        // Categories
        Task<IEnumerable<StockExitCategoryDto>> GetAllExitCategoriesAsync();
        Task<StockExitCategoryDto> AddExitCategoryAsync(CreateStockExitCategoryDto dto);
        Task<StockExitCategoryDto> UpdateExitCategoryAsync(Guid id, CreateStockExitCategoryDto dto);
        Task DeleteExitCategoryAsync(Guid id);
    }
}