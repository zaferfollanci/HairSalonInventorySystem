using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using HairSalonInventory.Application.DTOs;

namespace HairSalonInventory.Application.Interfaces
{
    public interface IExpenseService
    {
        Task<IEnumerable<ExpenseDto>> GetAllAsync(Guid? branchId = null);
        Task<ExpenseDto> GetByIdAsync(Guid id);
        Task<ExpenseDto> CreateAsync(CreateExpenseDto dto);
        Task DeleteAsync(Guid id);
    }
}