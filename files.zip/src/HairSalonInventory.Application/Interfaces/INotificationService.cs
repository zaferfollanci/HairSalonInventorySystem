using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using HairSalonInventory.Application.DTOs;
using HairSalonInventory.Domain.Entities;

namespace HairSalonInventory.Application.Interfaces
{
    public interface INotificationService
    {
        Task<List<NotificationDto>> GetUnreadAsync(Guid? userId = null, int limit = 10);
        Task<List<NotificationDto>> GetAllAsync(Guid? userId = null, int limit = 50);
        Task MarkAsReadAsync(Guid notificationId);
        Task MarkAllAsReadAsync(Guid? userId = null);

        Task NotifyLowStockAsync(Guid productId, string productName, decimal currentStock, decimal minStock, IEnumerable<string> adminEmails);
        Task NotifyCriticalAsync(string message, IEnumerable<string> adminEmails);
        Task BroadcastAsync(Notification notification);
    }
}