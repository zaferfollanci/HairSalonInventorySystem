using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using HairSalonInventory.Application.DTOs;

namespace HairSalonInventory.Application.Interfaces
{
    public interface ISaleService
    {
        Task<IEnumerable<SaleDto>> GetAllAsync(Guid? branchId = null);
        Task<SaleDto> GetByIdAsync(Guid id);
        Task<SaleDto> CreateAsync(CreateSaleDto dto);
        Task DeleteAsync(Guid id);
    }
}