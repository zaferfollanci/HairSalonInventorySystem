public interface IProductService
{
    // ...existing...
    Task<ProductDto> GetByBarcodeAsync(string barcode);
    Task<ProductDto> GetByQrDataAsync(string qrData);
}