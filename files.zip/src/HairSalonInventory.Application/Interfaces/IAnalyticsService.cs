using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using HairSalonInventory.Application.DTOs;

namespace HairSalonInventory.Application.Interfaces
{
    public interface IAnalyticsService
    {
        Task<List<ProductConsumptionDto>> GetTopConsumedProductsAsync(DateTime from, DateTime to, Guid? branchId = null);
        Task<List<MonthlyStockMovementDto>> GetMonthlyStockMovementsAsync(DateTime from, DateTime to, Guid? branchId = null);
        Task<List<StockTrendDto>> GetProductTrendsAsync(Guid productId, DateTime from, DateTime to, Guid? branchId = null);
    }
}