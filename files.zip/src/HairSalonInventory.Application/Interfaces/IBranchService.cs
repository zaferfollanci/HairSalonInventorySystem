using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using HairSalonInventory.Application.DTOs;

namespace HairSalonInventory.Application.Interfaces
{
    public interface IBranchService
    {
        Task<IEnumerable<BranchDto>> GetAllAsync();
        Task<BranchDto> GetByIdAsync(Guid id);
        Task<BranchDto> CreateAsync(CreateBranchDto dto);
        Task<BranchDto> UpdateAsync(Guid id, CreateBranchDto dto);
        Task DeleteAsync(Guid id);
    }
}