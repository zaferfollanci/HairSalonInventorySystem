using System;

namespace HairSalonInventory.Domain.Entities
{
    public class Sale
    {
        public Guid Id { get; set; }
        public Guid ProductId { get; set; }
        public Product Product { get; set; }
        public int Quantity { get; set; }
        public decimal UnitPrice { get; set; }
        public decimal Total => Quantity * UnitPrice;
        public DateTime Date { get; set; }
        public string CustomerName { get; set; }
        public Guid BranchId { get; set; }
        public Branch Branch { get; set; }
        public Guid? UserId { get; set; }
        public User User { get; set; }
    }
}