using System;

namespace HairSalonInventory.Domain.Entities
{
    public enum NotificationType
    {
        Info,
        Warning,
        Critical,
        LowStock
    }

    public class Notification
    {
        public Guid Id { get; set; }
        public NotificationType Type { get; set; }
        public string Message { get; set; }
        public bool IsRead { get; set; }
        public DateTime CreatedAt { get; set; }
        public Guid? UserId { get; set; } // null: system-wide
        public Guid? ProductId { get; set; }
        public string ProductName { get; set; }
    }
}