using System;
using System.Collections.Generic;

namespace HairSalonInventory.Domain.Entities
{
    public class Product
    {
        public Guid Id { get; set; }
        public string Name { get; set; }
        public string Unit { get; set; }
        public int MinimumStockLevel { get; set; }
        public DateTime? ExpirationDate { get; set; }
        public Guid? SupplierId { get; set; }
        public Supplier Supplier { get; set; }
        public ICollection<StockMovement> StockMovements { get; set; } = new List<StockMovement>();
        public Guid BranchId { get; set; }
        public Branch Branch { get; set; }
        public bool IsActive { get; set; } = true;
        public string Barcode { get; set; } // EAN-13, Code128, etc.
        public string QrData { get; set; } // Optional, for custom QR code data
    }
}