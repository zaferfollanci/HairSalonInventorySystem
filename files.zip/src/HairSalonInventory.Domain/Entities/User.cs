using Microsoft.AspNetCore.Identity;
using System;
using System.Collections.Generic;

namespace HairSalonInventory.Domain.Entities
{
    public class User : IdentityUser<Guid>
    {
        public UserRole Role { get; set; }
        public Guid BranchId { get; set; }
        public Branch Branch { get; set; }
        public ICollection<StockMovement> StockMovements { get; set; } = new List<StockMovement>();
    }

    public enum UserRole
    {
        Admin,
        Staff,
        Cashier
    }
}