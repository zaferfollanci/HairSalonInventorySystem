using System;

namespace HairSalonInventory.Domain.Entities
{
    public enum StockMovementType { Entry, Exit }

    public class StockMovement
    {
        public Guid Id { get; set; }
        public StockMovementType Type { get; set; }
        public Guid ProductId { get; set; }
        public Product Product { get; set; }
        public decimal Amount { get; set; }
        public DateTime Date { get; set; }
        public string Notes { get; set; }
        public Guid? ExitCategoryId { get; set; }
        public StockExitCategory ExitCategory { get; set; }
        public Guid? UserId { get; set; }
        public User User { get; set; }
        public Guid BranchId { get; set; }
        public Branch Branch { get; set; }
    }
}