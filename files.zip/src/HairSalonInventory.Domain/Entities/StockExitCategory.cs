using System;
using System.Collections.Generic;

namespace HairSalonInventory.Domain.Entities
{
    public class StockExitCategory
    {
        public Guid Id { get; set; }
        public string Name { get; set; }
        public ICollection<StockMovement> StockMovements { get; set; } = new List<StockMovement>();
    }
}