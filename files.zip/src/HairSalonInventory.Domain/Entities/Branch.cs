using System;
using System.Collections.Generic;

namespace HairSalonInventory.Domain.Entities
{
    public class Branch
    {
        public Guid Id { get; set; }
        public string Name { get; set; }
        public string Address { get; set; }
        public ICollection<Product> Products { get; set; } = new List<Product>();
        public ICollection<StockMovement> StockMovements { get; set; } = new List<StockMovement>();
        public ICollection<User> Users { get; set; } = new List<User>();
    }
}