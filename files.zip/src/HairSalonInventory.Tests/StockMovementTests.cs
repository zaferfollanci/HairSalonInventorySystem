using Xunit;
using System.Net.Http;
using System.Threading.Tasks;
using System.Net;
using System.Net.Http.Json;
using HairSalonInventory.Application.DTOs;

public class StockMovementTests : IClassFixture<CustomWebApplicationFactory<HairSalonInventory.API.Program>>
{
    private readonly HttpClient _client;

    public StockMovementTests(CustomWebApplicationFactory<HairSalonInventory.API.Program> factory)
    {
        _client = factory.CreateClient();
    }

    [Fact]
    public async Task CanCreateStockEntry()
    {
        // Arrange, Act, Assert as before...
    }
}