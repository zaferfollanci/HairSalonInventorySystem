using Xunit;
using System.Net.Http;
using System.Threading.Tasks;
using System.Net;

public class AuditLogTests : IClassFixture<CustomWebApplicationFactory<HairSalonInventory.API.Program>>
{
    private readonly HttpClient _client;
    public AuditLogTests(CustomWebApplicationFactory<HairSalonInventory.API.Program> factory)
    {
        _client = factory.CreateClient();
    }

    [Fact]
    public async Task CanQueryAuditLogs()
    {
        var response = await _client.GetAsync("api/AuditLog");
        Assert.Equal(HttpStatusCode.OK, response.StatusCode);
    }
}