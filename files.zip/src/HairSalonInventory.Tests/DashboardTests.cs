using Xunit;
using System.Net.Http;
using System.Threading.Tasks;
using System.Net;

public class DashboardTests : IClassFixture<CustomWebApplicationFactory<HairSalonInventory.API.Program>>
{
    private readonly HttpClient _client;
    public DashboardTests(CustomWebApplicationFactory<HairSalonInventory.API.Program> factory)
    {
        _client = factory.CreateClient();
    }

    [Fact]
    public async Task CanGetDashboardAnalytics()
    {
        var from = DateTime.UtcNow.AddMonths(-1).ToString("yyyy-MM-dd");
        var to = DateTime.UtcNow.ToString("yyyy-MM-dd");
        var response = await _client.GetAsync($"api/Analytics/monthly?from={from}&to={to}");
        Assert.Equal(HttpStatusCode.OK, response.StatusCode);
    }
}