using Xunit;
using System.Net.Http;
using System.Threading.Tasks;
using System.Net;

public class NotificationTests : IClassFixture<CustomWebApplicationFactory<HairSalonInventory.API.Program>>
{
    private readonly HttpClient _client;
    public NotificationTests(CustomWebApplicationFactory<HairSalonInventory.API.Program> factory)
    {
        _client = factory.CreateClient();
    }

    [Fact]
    public async Task CanGetUnreadNotifications()
    {
        var response = await _client.GetAsync("api/Notification/unread");
        Assert.Equal(HttpStatusCode.OK, response.StatusCode);
    }
}