using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using HairSalonInventory.Domain.Entities;

namespace HairSalonInventory.Infrastructure.Repositories
{
    public interface IAuditLogRepository
    {
        Task AddAsync(AuditLog log);
        Task<IEnumerable<AuditLog>> QueryAsync(DateTime? from, DateTime? to, string userName, string actionType, string entityName, int page = 1, int pageSize = 50);
    }
}