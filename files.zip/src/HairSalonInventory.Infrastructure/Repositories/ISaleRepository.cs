using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using HairSalonInventory.Domain.Entities;

namespace HairSalonInventory.Infrastructure.Repositories
{
    public interface ISaleRepository
    {
        Task<IEnumerable<Sale>> GetAllAsync(Guid? branchId = null);
        Task<Sale> GetByIdAsync(Guid id);
        Task AddAsync(Sale sale);
        Task DeleteAsync(Guid id);
    }
}