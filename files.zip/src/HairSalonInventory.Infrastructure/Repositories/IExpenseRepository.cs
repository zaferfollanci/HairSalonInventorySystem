using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using HairSalonInventory.Domain.Entities;

namespace HairSalonInventory.Infrastructure.Repositories
{
    public interface IExpenseRepository
    {
        Task<IEnumerable<Expense>> GetAllAsync(Guid? branchId = null);
        Task<Expense> GetByIdAsync(Guid id);
        Task AddAsync(Expense expense);
        Task DeleteAsync(Guid id);
    }
}