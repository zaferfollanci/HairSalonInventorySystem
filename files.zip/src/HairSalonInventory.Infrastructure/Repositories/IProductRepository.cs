using System.Threading.Tasks;
using HairSalonInventory.Domain.Entities;

public interface IProductRepository
{
    // ...existing methods...
    Task<Product> GetByBarcodeAsync(string barcode);
    Task<Product> GetByQrDataAsync(string qrData);
}