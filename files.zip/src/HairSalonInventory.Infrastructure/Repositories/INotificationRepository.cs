using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using HairSalonInventory.Domain.Entities;

namespace HairSalonInventory.Infrastructure.Repositories
{
    public interface INotificationRepository
    {
        Task AddAsync(Notification notification);
        Task<List<Notification>> GetUnreadAsync(Guid? userId = null, int limit = 10);
        Task<List<Notification>> GetAllAsync(Guid? userId = null, int limit = 50);
        Task MarkAsReadAsync(Guid notificationId);
        Task MarkAllAsReadAsync(Guid? userId = null);
    }
}