using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using HairSalonInventory.Domain.Entities;

namespace HairSalonInventory.Infrastructure.Repositories
{
    public class SupplierRepository : ISupplierRepository
    {
        private readonly AppDbContext _context;
        public SupplierRepository(AppDbContext context) => _context = context;

        public async Task<IEnumerable<Supplier>> GetAllAsync() => 
            await _context.Suppliers.ToListAsync();

        public async Task<Supplier> GetByIdAsync(Guid id) => 
            await _context.Suppliers.FindAsync(id);

        public async Task AddAsync(Supplier supplier)
        {
            _context.Suppliers.Add(supplier);
            await _context.SaveChangesAsync();
        }

        public async Task UpdateAsync(Supplier supplier)
        {
            _context.Suppliers.Update(supplier);
            await _context.SaveChangesAsync();
        }

        public async Task DeleteAsync(Guid id)
        {
            var s = await _context.Suppliers.FindAsync(id);
            if (s != null)
            {
                _context.Suppliers.Remove(s);
                await _context.SaveChangesAsync();
            }
        }
    }
}