using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using HairSalonInventory.Domain.Entities;

namespace HairSalonInventory.Infrastructure.Repositories
{
    public class AuditLogRepository : IAuditLogRepository
    {
        private readonly AppDbContext _context;
        public AuditLogRepository(AppDbContext context) => _context = context;

        public async Task AddAsync(AuditLog log)
        {
            _context.AuditLogs.Add(log);
            await _context.SaveChangesAsync();
        }

        public async Task<IEnumerable<AuditLog>> QueryAsync(
            DateTime? from, DateTime? to, string userName, string actionType, string entityName, int page = 1, int pageSize = 50)
        {
            var query = _context.AuditLogs.AsQueryable();

            if (from.HasValue) query = query.Where(x => x.Timestamp >= from.Value);
            if (to.HasValue) query = query.Where(x => x.Timestamp <= to.Value);
            if (!string.IsNullOrWhiteSpace(userName)) query = query.Where(x => x.UserName == userName);
            if (!string.IsNullOrWhiteSpace(actionType)) query = query.Where(x => x.ActionType == actionType);
            if (!string.IsNullOrWhiteSpace(entityName)) query = query.Where(x => x.EntityName == entityName);

            return await query.OrderByDescending(x => x.Timestamp)
                .Skip((page - 1) * pageSize)
                .Take(pageSize)
                .ToListAsync();
        }
    }
}