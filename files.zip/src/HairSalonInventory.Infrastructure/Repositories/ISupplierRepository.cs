using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using HairSalonInventory.Domain.Entities;

namespace HairSalonInventory.Infrastructure.Repositories
{
    public interface ISupplierRepository
    {
        Task<IEnumerable<Supplier>> GetAllAsync();
        Task<Supplier> GetByIdAsync(Guid id);
        Task AddAsync(Supplier supplier);
        Task UpdateAsync(Supplier supplier);
        Task DeleteAsync(Guid id);
    }
}