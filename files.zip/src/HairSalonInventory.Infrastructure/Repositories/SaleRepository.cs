using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using HairSalonInventory.Domain.Entities;

namespace HairSalonInventory.Infrastructure.Repositories
{
    public class SaleRepository : ISaleRepository
    {
        private readonly AppDbContext _context;
        public SaleRepository(AppDbContext context) => _context = context;

        public async Task<IEnumerable<Sale>> GetAllAsync(Guid? branchId = null)
        {
            var query = _context.Sales.Include(x => x.Product).Include(x => x.Branch).AsQueryable();
            if (branchId.HasValue)
                query = query.Where(x => x.BranchId == branchId.Value);
            return await query.OrderByDescending(x => x.Date).ToListAsync();
        }

        public async Task<Sale> GetByIdAsync(Guid id) =>
            await _context.Sales.Include(x => x.Product).Include(x => x.Branch).FirstOrDefaultAsync(x => x.Id == id);

        public async Task AddAsync(Sale sale)
        {
            _context.Sales.Add(sale);
            await _context.SaveChangesAsync();
        }

        public async Task DeleteAsync(Guid id)
        {
            var s = await _context.Sales.FindAsync(id);
            if (s != null)
            {
                _context.Sales.Remove(s);
                await _context.SaveChangesAsync();
            }
        }
    }
}