using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using HairSalonInventory.Domain.Entities;

namespace HairSalonInventory.Infrastructure.Repositories
{
    public interface IStockMovementRepository
    {
        Task<IEnumerable<StockMovement>> GetAllAsync(Guid? branchId = null, Guid? productId = null);
        Task<StockMovement> GetByIdAsync(Guid id);
        Task AddAsync(StockMovement movement);
        Task DeleteAsync(Guid id);
        Task<IEnumerable<StockExitCategory>> GetAllExitCategoriesAsync();
        Task<StockExitCategory> GetExitCategoryByIdAsync(Guid id);
        Task<StockExitCategory> AddExitCategoryAsync(StockExitCategory category);
        Task<StockExitCategory> UpdateExitCategoryAsync(StockExitCategory category);
        Task DeleteExitCategoryAsync(Guid id);
    }
}