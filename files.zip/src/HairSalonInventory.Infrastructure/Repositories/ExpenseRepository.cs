using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using HairSalonInventory.Domain.Entities;

namespace HairSalonInventory.Infrastructure.Repositories
{
    public class ExpenseRepository : IExpenseRepository
    {
        private readonly AppDbContext _context;
        public ExpenseRepository(AppDbContext context) => _context = context;

        public async Task<IEnumerable<Expense>> GetAllAsync(Guid? branchId = null)
        {
            var query = _context.Expenses.Include(x => x.Branch).AsQueryable();
            if (branchId.HasValue)
                query = query.Where(x => x.BranchId == branchId.Value);
            return await query.OrderByDescending(x => x.Date).ToListAsync();
        }

        public async Task<Expense> GetByIdAsync(Guid id) =>
            await _context.Expenses.Include(x => x.Branch).FirstOrDefaultAsync(x => x.Id == id);

        public async Task AddAsync(Expense expense)
        {
            _context.Expenses.Add(expense);
            await _context.SaveChangesAsync();
        }

        public async Task DeleteAsync(Guid id)
        {
            var exp = await _context.Expenses.FindAsync(id);
            if (exp != null)
            {
                _context.Expenses.Remove(exp);
                await _context.SaveChangesAsync();
            }
        }
    }
}