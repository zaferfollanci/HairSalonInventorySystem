using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using HairSalonInventory.Domain.Entities;

namespace HairSalonInventory.Infrastructure.Repositories
{
    public class NotificationRepository : INotificationRepository
    {
        private readonly AppDbContext _context;
        public NotificationRepository(AppDbContext context) => _context = context;

        public async Task AddAsync(Notification notification)
        {
            _context.Notifications.Add(notification);
            await _context.SaveChangesAsync();
        }

        public async Task<List<Notification>> GetUnreadAsync(Guid? userId = null, int limit = 10)
        {
            return await _context.Notifications
                .Where(n => !n.IsRead && (!userId.HasValue || n.UserId == userId || n.UserId == null))
                .OrderByDescending(n => n.CreatedAt)
                .Take(limit)
                .ToListAsync();
        }

        public async Task<List<Notification>> GetAllAsync(Guid? userId = null, int limit = 50)
        {
            return await _context.Notifications
                .Where(n => !userId.HasValue || n.UserId == userId || n.UserId == null)
                .OrderByDescending(n => n.CreatedAt)
                .Take(limit)
                .ToListAsync();
        }

        public async Task MarkAsReadAsync(Guid notificationId)
        {
            var notif = await _context.Notifications.FindAsync(notificationId);
            if (notif != null)
            {
                notif.IsRead = true;
                await _context.SaveChangesAsync();
            }
        }

        public async Task MarkAllAsReadAsync(Guid? userId = null)
        {
            var notifs = await _context.Notifications
                .Where(n => !n.IsRead && (!userId.HasValue || n.UserId == userId || n.UserId == null))
                .ToListAsync();
            foreach (var n in notifs) n.IsRead = true;
            await _context.SaveChangesAsync();
        }
    }
}