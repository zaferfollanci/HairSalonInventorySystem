using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using HairSalonInventory.Domain.Entities;

namespace HairSalonInventory.Infrastructure.Repositories
{
    public class StockMovementRepository : IStockMovementRepository
    {
        private readonly AppDbContext _context;
        public StockMovementRepository(AppDbContext context)
        {
            _context = context;
        }

        public async Task<IEnumerable<StockMovement>> GetAllAsync(Guid? branchId = null, Guid? productId = null)
        {
            var query = _context.StockMovements
                .Include(sm => sm.Product)
                .Include(sm => sm.ExitCategory)
                .Include(sm => sm.User)
                .Include(sm => sm.Branch)
                .AsQueryable();

            if (branchId.HasValue)
                query = query.Where(sm => sm.BranchId == branchId);

            if (productId.HasValue)
                query = query.Where(sm => sm.ProductId == productId);

            return await query.OrderByDescending(sm => sm.Date).ToListAsync();
        }

        public async Task<StockMovement> GetByIdAsync(Guid id)
        {
            return await _context.StockMovements
                .Include(sm => sm.Product)
                .Include(sm => sm.ExitCategory)
                .Include(sm => sm.User)
                .Include(sm => sm.Branch)
                .FirstOrDefaultAsync(sm => sm.Id == id);
        }

        public async Task AddAsync(StockMovement movement)
        {
            _context.StockMovements.Add(movement);
            await _context.SaveChangesAsync();
        }

        public async Task DeleteAsync(Guid id)
        {
            var sm = await _context.StockMovements.FindAsync(id);
            if (sm != null)
            {
                _context.StockMovements.Remove(sm);
                await _context.SaveChangesAsync();
            }
        }

        public async Task<IEnumerable<StockExitCategory>> GetAllExitCategoriesAsync()
        {
            return await _context.StockExitCategories.OrderBy(c => c.Name).ToListAsync();
        }

        public async Task<StockExitCategory> GetExitCategoryByIdAsync(Guid id)
        {
            return await _context.StockExitCategories.FirstOrDefaultAsync(c => c.Id == id);
        }

        public async Task<StockExitCategory> AddExitCategoryAsync(StockExitCategory category)
        {
            _context.StockExitCategories.Add(category);
            await _context.SaveChangesAsync();
            return category;
        }

        public async Task<StockExitCategory> UpdateExitCategoryAsync(StockExitCategory category)
        {
            _context.StockExitCategories.Update(category);
            await _context.SaveChangesAsync();
            return category;
        }

        public async Task DeleteExitCategoryAsync(Guid id)
        {
            var cat = await _context.StockExitCategories.FindAsync(id);
            if (cat != null)
            {
                _context.StockExitCategories.Remove(cat);
                await _context.SaveChangesAsync();
            }
        }
    }
}