public async Task<Product> GetByBarcodeAsync(string barcode)
{
    return await _context.Products
        .Include(p => p.Supplier)
        .FirstOrDefaultAsync(p => p.Barcode == barcode);
}
public async Task<Product> GetByQrDataAsync(string qrData)
{
    return await _context.Products
        .Include(p => p.Supplier)
        .FirstOrDefaultAsync(p => p.QrData == qrData);
}