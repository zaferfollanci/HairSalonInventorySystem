window.startBarcodeQrScanner = function (dotnetHelper) {
    if (window.html5QrCodeScanner) {
        window.html5QrCodeScanner.clear();
    }
    window.html5QrCodeScanner = new Html5Qrcode("barcode-scanner");
    window.html5QrCodeScanner.start(
        { facingMode: "environment" },
        {
            fps: 10,
            qrbox: 250
        },
        qrCodeMessage => {
            dotnetHelper.invokeMethodAsync('OnDetected', qrCodeMessage);
            window.html5QrCodeScanner.stop();
        },
        errorMessage => {}
    );
}