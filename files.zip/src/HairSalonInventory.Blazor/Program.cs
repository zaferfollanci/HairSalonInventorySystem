using Microsoft.Extensions.Localization;
using System.Globalization;

var builder = WebApplication.CreateBuilder(args);

// Add localization
builder.Services.AddLocalization(options => options.ResourcesPath = "Resources");

var supportedCultures = new[] { "en", "tr" };
var defaultCulture = "en";

builder.Services.Configure<RequestLocalizationOptions>(options =>
{
    options.DefaultRequestCulture = new Microsoft.AspNetCore.Localization.RequestCulture(defaultCulture);
    options.SupportedUICultures = supportedCultures.Select(x => new CultureInfo(x)).ToList();
    options.SupportedCultures = supportedCultures.Select(x => new CultureInfo(x)).ToList();
});

// ... existing code ...